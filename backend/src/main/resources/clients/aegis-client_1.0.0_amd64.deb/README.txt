AegisAI Client v1.0.0 - Placeholder Installer

This is a placeholder file. The actual client installer will be available
when the Electron app is compiled.

To build from source:
  cd electron
  npm install
  npm run build:win   # for Windows
  npm run build:mac   # for macOS  
  npm run build:linux # for Linux

Source code: https://github.com/SERIOUSBEAST69/AegisAI/tree/main/electron
